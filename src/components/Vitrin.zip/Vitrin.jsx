// src/components/Vitrin.jsx
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { getProviderIconFinal } from "../utils/providerIcons";
import { sendClick } from "../api/click";
import { useAuth } from "../hooks/useAuth";
import { getDeviceId } from "../utils/device";
import { smartVitrinProcess } from "../utils/vitrinSmartCore";
import { getLastQuery } from "../utils/searchBridge";
import { pickImportantBadges } from "../utils/badgeSelect";
import BadgePanel from "./BadgePanel";
import VerifiedBadge from "./VerifiedBadge";

// ⭐ Yeni eklenen importlar
import BadgeTag from "./BadgeTag";
import { BADGE_LABELS } from "../utils/badgeMap";

// 🔥 Evrensel Herkül Click Redirect Handler
// ================================================
async function handleAffiliateRedirect(item, source = "unknown", user = null) {
  try {
    if (!item || !item.url) return;

    // 1) Referral cookie oku
    let ref = null;
    try {
      ref =
        localStorage.getItem("referral") ||
        localStorage.getItem("ref") ||
        null;
    } catch {}

    // 2) Backend'e CLICK kaydı gönder
    let clickId = null;
    try {
      const payload = {
        userId: user?.id || null,
        provider: item.provider || "unknown",
        productId: item.id || item.productId || null,
        productName: item.title || item.name || "",
        price: item.optimizedPrice || item.finalPrice || item.price || 0,
        referralCode: ref,
        source,
      };

      const r = await sendClick(payload);

      if (r && r.ok && r.clickId) {
        clickId = r.clickId;
      }
    } catch (e) {
      console.warn("Herkül Click → kayıt yapılamadı:", e);
    }

    // 3) Affiliate linke clickId ekle
    let finalUrl = item.url;

    try {
      if (clickId) {
        const hasQuery = finalUrl.includes("?");
        finalUrl = `${finalUrl}${hasQuery ? "&" : "?"}click_id=${clickId}`;
      }
    } catch {}

    // 4) Her şey hazır → kullanıcıyı yönlendir
    window.open(finalUrl, "_blank", "noopener");
  } catch (err) {
    console.error("Herkül Redirect Hatası:", err);
  }
}

export default function Vitrin() {
  const { t, i18n } = useTranslation();

  const [best, setBest] = useState([]);
  const [smart, setSmart] = useState([]);
  const [others, setOthers] = useState([]);
  const [cursor, setCursor] = useState(0);
  const [loading, setLoading] = useState(false);

  const initialLastQuery =
    getLastQuery() ||
    ((typeof window !== "undefined" &&
      window.localStorage &&
      window.localStorage.getItem("lastQuery")) ||
      "");

  const [lastQuery, setLastQuery] = useState(initialLastQuery);
  const [highlight, setHighlight] = useState(false);

  const [smartIndex, setSmartIndex] = useState(0);
  const [otherIndex, setOtherIndex] = useState(0);
  const [hoverSmart, setHoverSmart] = useState(false);
  const [hoverOther, setHoverOther] = useState(false);
  const [couponCodeInput, setCouponCodeInput] = useState("");
  const [activeCouponCode, setActiveCouponCode] = useState("");
  const [couponApplyMsg, setCouponApplyMsg] = useState("");

  const { user, isLoggedIn } = useAuth();

  // ============================================================
  // Kupon Uygulama (tüm vitrin için tek aktif kupon)
  // ============================================================
  async function applyCouponGlobal() {
    setCouponApplyMsg("");

    const code = (couponCodeInput || "").trim().toUpperCase();
    if (!code) {
      setCouponApplyMsg(
        t("wallet.enterCoupon", {
          defaultValue: "Lütfen bir kupon kodu gir.",
        })
      );
      return;
    }

    if (!isLoggedIn || !user || !user.id) {
      setCouponApplyMsg(
        t("wallet.mustLoginCoupon", {
          defaultValue: "Kupon kullanmak için giriş yapmalısın.",
        })
      );
      return;
    }

    try {
      const BASE = import.meta.env.VITE_BACKEND_URL || "";
      const r = await fetch(`${BASE}/api/coupons/apply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, userId: user.id }),
      });

      const j = await r.json().catch(() => ({}));

      if (!j.ok || !j.valid) {
        setActiveCouponCode("");
        setCouponApplyMsg(
          j.message ||
            t("wallet.couponInvalid", {
              defaultValue: "Kupon geçersiz veya kullanılamaz.",
            })
        );
        return;
      }

      setActiveCouponCode(j.code);
      setCouponApplyMsg(
        t("wallet.couponAppliedCashback", {
          defaultValue:
            "Kupon uygulandı. Bu tıklama sonrasında alışverişi tamamlarsan tutar cashback olarak cüzdanına eklenecek.",
        })
      );
    } catch (e) {
      setActiveCouponCode("");
      setCouponApplyMsg(
        e?.message ||
          t("wallet.couponError", {
            defaultValue: "Kupon doğrulanırken bir hata oluştu.",
          })
      );
    }
  }

  // ============================================================
  //   🔥 Rezervasyon Motoru — Güçlü & Güvenli
  // ============================================================
  async function reserve(item, source = "unknown") {
    try {
      if (!item || !item.url) {
        console.warn("reserve: Eksik ürün bilgisi", item);
        return;
      }

      // provider eksik olsa bile akışı bozma
      const provider = item.provider || "unknown";

      const token = localStorage.getItem("token") || "";
      const deviceId = getDeviceId();

      // 1) CLICK KAYDI — sadece login kullanıcı için
      let clickResponse = null;

      if (isLoggedIn && user?.id) {
        try {
          // Referral cookie
          let ref = null;
          try {
            ref =
              localStorage.getItem("referral") ||
              localStorage.getItem("ref") ||
              null;
          } catch {}

          clickResponse = await sendClick({
            userId: user.id,
            productId: item.id || item.productId || null,
            provider,
            price: item.optimizedPrice || item.finalPrice || item.price || 0,
            source,
            deviceId,
            referralCode: ref,
            appliedCouponCode:
              localStorage.getItem("activeCoupon") || null,
          });
        } catch (e) {
          console.warn("reserve → sendClick hata:", e);
        }
      }

      const clickId =
        clickResponse?.clickId ||
        clickResponse?.id ||
        clickResponse?.data?.clickId ||
        null;

      // 2) ADAPTER → AFFILIATE URL ÜRET
      let finalUrl = item.url;

      try {
        const res = await fetch(
          `${import.meta.env.VITE_BACKEND_URL || ""}/api/affiliate/url`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: JSON.stringify({
              provider,
              productUrl: item.url,
              productId: item.id || item.productId || null,
              clickId,
            }),
          }
        );

        const data = await res.json().catch(() => null);

        if (data && data.ok && data.affiliateUrl) {
          finalUrl = data.affiliateUrl;
        }
      } catch (err) {
        console.warn("reserve → affiliate url alınamadı:", err);
      }

      // 3) KULLANICIYI YÖNLENDİR
      window.open(finalUrl, "_blank", "noopener");

      // 4) EVENT Bildirimi (genel sistem uyumu)
      try {
        window.dispatchEvent(
          new CustomEvent("fie:click", {
            detail: {
              provider,
              price: item.price,
              source,
              query: localStorage.getItem("lastQuery") || "",
            },
          })
        );
      } catch {
        // event patlarsa bile rezervasyon patlamasın
      }
    } catch (e) {
      console.error("reserve hata:", e);
    }
  }

  // ============================================================
  // Global arama tetikleyicisi (fae.vitrine.search)
  // ============================================================
  useEffect(() => {
    function handleSearch(e) {
      const q = e.detail?.query;
      if (!q) return;

      try {
        if (typeof window !== "undefined" && window.localStorage) {
          window.localStorage.setItem("lastQuery", q);
        }
      } catch {}

      setLastQuery(q);
      loadVitrine(true);
    }

    if (typeof window !== "undefined") {
      window.addEventListener("fae.vitrine.search", handleSearch);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("fae.vitrine.search", handleSearch);
      }
    };
  }, []);

  async function handleGo(item) {
    if (isLoggedIn) {
      try {
        await sendClick({
          userId: user.id,
          productId: item.id || item.productId || null,
          provider: item.provider,
          price: item.optimizedPrice || item.finalPrice || item.price || 0,
        });
      } catch (e) {}
    }
    if (item.url) window.open(item.url, "_blank");
  }

  function safeNumber(value, fallback = null) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function normalizeArray(raw) {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw.filter(Boolean);
    return [raw];
  }

  function getSafeTrust(item) {
    const v =
      typeof item?.trustScore === "number" && item.trustScore >= 0
        ? item.trustScore
        : 0.75;
    return Math.round(Math.min(1, Math.max(0, v)) * 100);
  }

  function getSafeRating(item) {
    const v =
      typeof item?.rating === "number" && item.rating > 0
        ? Math.min(5, item.rating)
        : null;
    return v !== null ? Math.round(v * 10) / 10 : null;
  }

  function getSafeQuality5(item) {
    const v =
      typeof item?.qualityScore5 === "number" && item.qualityScore5 > 0
        ? Math.min(5, item.qualityScore5)
        : null;
    return v !== null ? Math.round(v * 10) / 10 : null;
  }

  function getFinalPrice(item) {
    if (!item) return null;
    const opt = safeNumber(item.optimizedPrice, null);
    const base = safeNumber(item.price, null);
    if (opt !== null && opt > 0) return opt;
    if (base !== null && base > 0) return base;
    return null;
  }

  // ============================================================
  // 🔥 VİTRİN MOTORU — Tüm sorunlar düzeltilmiş stabil sürüm
  // ============================================================
  async function loadVitrine(reset = false) {
    if (typeof window !== "undefined" && window.__vitrineLoading) return;
    if (typeof window !== "undefined") window.__vitrineLoading = true;

    try {
      setLoading(true);

      const queryForBody = getLastQuery() || lastQuery || "";

      const body = {
        query: queryForBody,
        region:
          (typeof window !== "undefined" &&
            window.localStorage &&
            window.localStorage.getItem("region")) ||
          "TR",
        locale: i18n.language || "tr",
        cursor: reset ? 0 : cursor,
      };

      const BASE = import.meta.env.VITE_BACKEND_URL || "";

      const r = await fetch(`${BASE}/api/vitrin/dynamic`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!r.ok) {
        setBest([]);
        setSmart([]);
        setOthers([]);
        return;
      }

      const j = await r.json().catch(() => ({}));

      if (j && j.ok) {
        const ensureArray = (v) => (Array.isArray(v) ? v : v ? [v] : []);
        const src = j.cards && !Array.isArray(j.cards) ? j.cards : j;

        let bestArr = ensureArray(src.best);
        let smartArr = ensureArray(src.smart);

        let othersArr = ensureArray(src.others);
        if (othersArr.length === 0) {
          othersArr = [
            {
              id: "fallback-1",
              title: "Alternatif Ürün Bulunamadı",
              provider: "FindAllEasy",
              price: null,
              rating: null,
              description:
                "Henüz yeterli veri yok, sistem öğrenmeye devam ediyor.",
            },
          ];
        }

        // Smart vitrin çekirdeği ile komisyon & kalite odaklı sıralama
        try {
          const allItems = [...bestArr, ...smartArr, ...othersArr].filter(
            Boolean
          );
          const processed = smartVitrinProcess({
            query: body.query,
            results: allItems,
          });

          if (
            processed &&
            Array.isArray(processed.results) &&
            processed.results.length
          ) {
            const [pBest, ...rest] = processed.results;
            const smartCount = smartArr.length || 4;
            const pSmart = rest.slice(0, smartCount);
            const pOthers = rest.slice(smartCount);

            if (pBest) bestArr = [pBest];
            if (pSmart.length) smartArr = pSmart;
            if (pOthers.length) othersArr = pOthers;
          }
        } catch (e) {
          console.warn("smartVitrinProcess hata:", e);
        }

        if (reset) {
          setBest(bestArr);
          setSmart(smartArr);
          setOthers(othersArr);
          setCursor(0);
        } else {
          setBest((p) => (p.length ? p : bestArr));
          setSmart((p) => (p.length ? p : smartArr));
          setOthers((p) => [...p, ...othersArr]);
        }

        if (typeof window !== "undefined") {
          window.dispatchEvent(
            new CustomEvent("sono:best-updated", {
              detail: { best: bestArr[0], query: body.query },
            })
          );
        }

        if (j.nextCursor !== undefined) setCursor(j.nextCursor);
      } else {
        setBest([]);
        setSmart([]);
        setOthers([]);
      }
    } catch (err) {
      console.error("Vitrin yüklenirken hata:", err);
      setBest([]);
      setSmart([]);
      setOthers([]);
    } finally {
      if (typeof window !== "undefined") {
        window.__vitrineLoading = false;
      }
      setLoading(false);
    }
  }

  // ============================================================
  //   🔥 Global yenileme (fae.vitrine.refresh)
  // ============================================================
  useEffect(() => {
    const handler = () => loadVitrine(true);
    if (typeof window !== "undefined") {
      window.addEventListener("fae.vitrine.refresh", handler);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("fae.vitrine.refresh", handler);
      }
    };
  }, []);

  // İlk yükleme
  useEffect(() => {
    loadVitrine(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Dil değişince yenile
  useEffect(() => {
    loadVitrine(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.language]);

  // ============================================================
  //   🔥 Vitrin event seti (tam senkron)
  // ============================================================
  useEffect(() => {
    const handleRefresh = () => loadVitrine(true);

    const handleSearch = (e) => {
      const q = e.detail?.query;
      if (!q) return;
      try {
        if (typeof window !== "undefined" && window.localStorage) {
          window.localStorage.setItem("lastQuery", q);
        }
      } catch {}
      setLastQuery(q);
      loadVitrine(true);
    };

    const handleFIE = (e) => {
      const { cards } = e.detail || {};
      if (!cards) return;

      const bestArr = normalizeArray(cards.best);
      const smartArr = normalizeArray(cards.smart);
      const othersArr = normalizeArray(cards.others);

      setBest(bestArr);
      setSmart(smartArr);
      setOthers(othersArr);
    };

    if (typeof window !== "undefined") {
      window.addEventListener("fae.vitrine.refresh", handleRefresh);
      window.addEventListener("vitrine-search", handleSearch);
      window.addEventListener("fie:vitrin", handleFIE);
      window.addEventListener("ai.search", handleSearch);
    }

    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("fae.vitrine.refresh", handleRefresh);
        window.removeEventListener("vitrine-search", handleSearch);
        window.removeEventListener("fie:vitrin", handleFIE);
        window.removeEventListener("ai.search", handleSearch);
      }
    };
  }, []);

  // Highlight animasyon
  useEffect(() => {
    if (!lastQuery) return;
    setHighlight(true);
    const to = setTimeout(() => setHighlight(false), 800);
    return () => clearTimeout(to);
  }, [lastQuery]);

  // Interaction logger
  async function logInteraction(type, item) {
    try {
      await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/api/vitrin/interactions`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId:
              (typeof window !== "undefined" &&
                window.localStorage &&
                window.localStorage.getItem("userId")) ||
              "anon",
            query:
              (typeof window !== "undefined" &&
                window.localStorage &&
                window.localStorage.getItem("lastQuery")) ||
              "",
            cardType: type,
            category: item?.category || "",
            region:
              (typeof window !== "undefined" &&
                window.localStorage &&
                window.localStorage.getItem("region")) ||
              "TR",
          }),
        }
      );
    } catch {}
  }

  function Tag({ children }) {
    return (
      <div className="px-2 py-1 text-xs rounded-xl border border-[#d4af37]/40 text-[#f9e7a5] bg-black/30 backdrop-blur-[3px]">
        {children}
      </div>
    );
  }

  function resolveImage(item) {
    if (!item) return null;
    return (
      item.image ||
      item.imageUrl ||
      item.img ||
      item.thumbnail ||
      item.thumb ||
      item.productImage ||
      item.productImageURL ||
      item.photo ||
      item.photoUrl ||
      (Array.isArray(item.photos) && item.photos[0]) ||
      (item.media && item.media.image) ||
      null
    );
  }
function InnerCard({ item, onClick }) {
  const safeTitle =
    typeof item?.title === "string" && item.title.trim().length > 0
      ? item.title
      : "—";

  const safeProvider =
    typeof item?.provider === "string" && item.provider.trim().length > 0
      ? item.provider
      : "unknown";

  const finalPrice = getFinalPrice(item);
  const fallbackPrice =
    typeof item?.price === "number" && item.price > 0 ? item.price : null;

  const showPrice = finalPrice ?? fallbackPrice;

  const icon = getProviderIconFinal(item?.provider);
  const img = resolveImage(item);

  const rating = getSafeRating(item);
  const q5 = getSafeQuality5(item);

  let discount = null;
  if (
    item?.commissionMeta &&
    typeof item.commissionMeta.discountApplied === "number" &&
    item.commissionMeta.discountApplied > 0
  ) {
    discount = Math.round(item.commissionMeta.discountApplied);
  }
return (
  <div
  onClick={onClick}
  className="
    bg-black/40 rounded-xl 
    p-3 mb-3 
    border border-[#d4af37]/25
    shadow-[inset_0_0_8px_rgba(255,255,255,0.1)]
    backdrop-blur-md
    transition-all duration-300 
    hover:bg-black/50 
    hover:border-[#d4af37]/40
    min-h-[100px]
    flex flex-col justify-between
    cursor-pointer 
    active:scale-[0.98]
  "
>


      {/* Üst Bilgi */}
      <div className="flex items-start justify-between text-white/90 text-xs mb-2">
        <div className="flex items-center gap-2">
          <span className="truncate max-w-[130px]">{safeTitle}</span>
          {icon && (
            <img src={icon} alt={safeProvider} className="w-3 h-3 opacity-90" />
          )}
        </div>

        {showPrice !== null && (
          <span className="text-[#f5d76e] font-semibold text-sm whitespace-nowrap">
            ₺{showPrice}
          </span>
        )}
      </div>

      {/* Görsel Alanı */}
    <div className="w-full h-[100px] overflow-hidden rounded-md bg-black/20 flex items-center justify-center mb-2 fae-image-area">

        {img ? (
          <img
            src={img}
            alt={safeTitle}
            className="max-h-[120px] w-auto object-contain"
            loading="lazy"
          />
        ) : (
          <span className="text-white/20 text-xs">Görsel yok</span>
        )}
      </div>

      {/* Alt Bilgi */}
      <div className="flex items-center flex-wrap text-[11px] text-[#f9e7a5] gap-3 mb-2">
        <VerifiedBadge />
        {rating !== null && <span>💬 {rating}/5</span>}
        {q5 !== null && <span>✔ {q5}/5</span>}
        {discount !== null && <span>💛 -₺{discount}</span>}
      </div>

      {/* 🔥 TIKLA BUTONU — Kartın içi */}
     
    </div>
  );
}


  return (
    <section
      className="
        w-full max-w-6xl mx-auto
        min-h-screen
        content-start
        grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3
        gap-3 lg:gap-4
      "
      style={{ alignItems: "stretch" }}
    >
      {/* KUPON UYGULAMA */}
      {/* (UI kısmını daha sonra dolduracaksan yine buradan devam edersin) */}

{/* === BEST === */}
<article
  className="
    flex flex-col justify-between
    rounded-lg
    **border-t border-x border-[#d4af37]/25 border-b-4 border-[#d4af37]**
    bg-[rgba(15,15,15,0.85)]
    p-3 pb-4
    shadow-[0_0_0_1px_rgba(212,175,55,0.1),0_2px_6px_rgba(0,0,0,0.3)]
    transform-gpu transition-all duration-500
    hover:shadow-[0_0_0_1px_rgba(212,175,55,0.15)]
    hover:translate-y-[-1px]
    backdrop-blur-xl min-h-[200px]
    relative overflow-hidden
    fae-vitrin-card
  "
>

  <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/5 to-transparent pointer-events-none" />

  <div className="relative z-10 flex flex-col gap-2 flex-1">
    <h3 className="text-[#f5d76e] font-semibold text-sm mb-1 tracking-wide">
      {t("showcase.best", { defaultValue: "En uygun & güvenilir" })}
    </h3>

    {best.length === 0 && (
      <p className="text-white/70 text-xs mb-1">
        {t("showcase.preparing", {
          defaultValue: "Öneriler hazırlanıyor...",
        })}
      </p>
    )}

    {best.length > 0 && (
      <InnerCard
        item={best[0]}
        onClick={() => {
          logInteraction("best", best[0]);
          reserve(best[0], "best");
        }}
      />
    )}
  </div>
</article>


{/* === SMART === */}
<article
  className="
    flex flex-col justify-between
    rounded-lg
    **border-t border-x border-[#d4af37]/25 border-b-4 border-[#d4af37]**
    bg-[rgba(15,15,15,0.85)]
    p-3 pb-4
    shadow-[0_0_0_1px_rgba(212,175,55,0.1),0_2px_6px_rgba(0,0,0,0.3)]
    transform-gpu transition-all duration-500
    hover:shadow-[0_0_0_1px_rgba(212,175,55,0.15)]
    hover:translate-y-[-1px]
    backdrop-blur-xl min-h-[200px]
    relative overflow-hidden
    fae-vitrin-card
  "
  onMouseEnter={() => setHoverSmart(true)}
  onMouseLeave={() => setHoverSmart(false)}
>
  <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/5 to-transparent pointer-events-none" />

  <div className="relative z-10 flex flex-col gap-2 flex-1">
    <h3 className="text-[#f5d76e] font-semibold text-sm mb-1 tracking-wide">
      {t("showcase.aiCumulative", {
        defaultValue: "SonoAI Önerileri",
      })}
    </h3>

    {smart.length === 0 && (
      <p className="text-white/70 text-xs">
        {t("showcase.personalizing", {
          defaultValue: "Kişiselleştiriliyor…",
        })}
      </p>
    )}

    {smart.length > 0 && (
      <InnerCard
        item={smart[smartIndex] || smart[0]}
        onClick={() => {
          const s = smart[smartIndex] || smart[0];
          logInteraction("smart", s);
          reserve(s, "smart");
        }}
      />
    )}
  </div>
</article>


{/* === OTHERS === */}
<article
  className="
    flex flex-col justify-between
    rounded-lg
    **border-t border-x border-[#d4af37]/25 border-b-4 border-[#d4af37]**
    bg-[rgba(15,15,15,0.85)]
    p-3 pb-4
    shadow-[0_0_0_1px_rgba(212,175,55,0.1),0_2px_6px_rgba(0,0,0,0.3)]
    transform-gpu transition-all duration-500
    hover:shadow-[0_0_0_1px_rgba(212,175,55,0.15)]
    hover:translate-y-[-1px]
    backdrop-blur-xl min-h-[200px]
    relative overflow-hidden
    fae-vitrin-card
  "
  onMouseEnter={() => setHoverOther(true)}
  onMouseLeave={() => setHoverOther(false)}
>
  <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/5 to-transparent pointer-events-none" />

  <div className="relative z-10 flex flex-col gap-2 flex-1">
    <h3 className="text-[#f5d76e] font-semibold text-sm mb-1 tracking-wide">
      {t("showcase.others", { defaultValue: "Diğerleri" })}
    </h3>

    {others.length === 0 && !loading && (
      <p className="text-white/70 text-xs">
        {t("showcase.noResults", {
          defaultValue: "Henüz sonuç bulunamadı.",
        })}
      </p>
    )}

    {loading && (
      <p className="text-white/60 text-xs py-1">
        {t("common.loading", { defaultValue: "Yükleniyor…" })}
      </p>
    )}

    {others.length > 0 && (
      <InnerCard
        item={others[otherIndex] || others[0]}
        onClick={() => {
          const o = others[otherIndex] || others[0];
          logInteraction("others", o);
          reserve(o, "others");
        }}
      />
    )}
  </div>
</article>

    </section>
  );
}